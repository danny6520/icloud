<?php
session_start();
if(isset($_SESSION['email_id']))
{
    session_destroy();
    //echo "<h2>Welcome " .$_SESSION['email_id']."!</h2>";
    echo "<script>location.href='login_icloud.html'</script>";
    //header ('Location: loginUser.php');
    }
    else{
        echo "<script>location.href='login_icloud.html'</script>";
        //header ('Location: loginUser.php');
     
}
?>