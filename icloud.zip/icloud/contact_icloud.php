<?php
$conn=new mysqli('localhost','u319732989_pupsyothakadai','Admin@123#p','u319732989_pupsyothakadai');

if($conn->connect_errno)
{
echo $conn->connect_error;
die();
}
else
{
//echo "Database connected";
}


if(isset($_POST['submit']))
{
    $name=$_POST['name'];
    $email=$_POST['email'];
	$subject=$_POST['subject'];
    $message=$_POST['message'];
	
	
        $sql="INSERT INTO contact_us (name,email,purpose,message) VALUES ('$name','$email','$subject','$message')";
       // echo $sql;
		if($conn->query($sql) === TRUE)
		{
			echo "<script>alert('Message sent successfully!')</script>";
			echo "<script>location.href='index.html'</script>";
		}	
		else
		{
			//echo "Insert data fail" . $sql . "<br>" . $conn->error;
		}
}
?>
