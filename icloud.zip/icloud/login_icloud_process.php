<?php
session_start();
?>
<?php
//$conn=new mysqli('remotemysql.com','zoGJXPbqT5','1QNCsdVSph','zoGJXPbqT5');
 $conn=new mysqli('localhost','u319732989_pupsyothakadai','Admin@123#p','u319732989_pupsyothakadai');

if($conn->connect_errno)
{
echo $conn->connect_error;
die();
}
else
{
echo "Loading...Please wait..!";
}
 
    $email_id=$_POST['email_id'];
	$password=$_POST['password'];
	$result=mysqli_query($conn, 'SELECT * from user_info where email_id="'.$email_id.'" AND password="'.$password.'"');
	if(mysqli_num_rows($result)==1)
	{
	    			$_SESSION['email_id']="$email_id";

			//$_SESSION['email_id']="$email_id";
			//echo "<h1>Welcome " .$_SESSION['uname']"!</h1>";
			//$_SESSION['shop']='Sony DIGICAM';
            //header ('Location: onlinetest.php');
            echo "<script>alert('Login successful!')</script>";

		   echo "<script>location.href='contact_icloud_admin.php'</script>";
		  // echo 'The value of shop '.$_SESSION['shop'];
	}
	else{
		echo "<script>alert('User name or password is incorrect!')</script>";
		echo "<script>location.href='login_icloud.html'</script>";
	}
	//if(isset($_GET['logout']))
	//{
	//	session_unregister('uname');
    //}
    ?>